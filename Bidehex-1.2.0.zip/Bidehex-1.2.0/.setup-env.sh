if type -p java; then
    _java=java
elif [[ -n "$JAVA_HOME" ]] && [[ -x "$JAVA_HOME/bin/java" ]];  then
    _java="$JAVA_HOME/bin/java"
fi

if [[ "$_java" ]]; then
    version=$("$_java" -version 2>&1 | awk -F '"' '/version/ {print $2}')
    # echo version "$version"
    if [[ "$version" < "21" ]]; then
        if [ ! -d "$SDKMAN_DIR" ]; then
            read -r -p "This app needs Java 21+ to run on your system! Do you want to download it? [y/N] " response
            if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
                curl -s "https://get.sdkman.io" | bash
            else
                exit 0
            fi
        fi
        
        source "$HOME/.sdkman/bin/sdkman-init.sh"
        sdk i java 21.0.4-graal
        sdk use java 21.0.4-graal
    fi
fi