./.setup-env.sh

if command -v native-image.cmd 2>&1 >/dev/null
then
    if [ "$1" != "--skip-agent" ]; then
        mkdir -p META-INF/native-image
        echo "Close the app to continue..."
        java -agentlib:native-image-agent=config-output-dir=META-INF/native-image -jar ./Bidehex-1.2.0.jar
        sleep 2s
    fi

    native-image.cmd -jar ./Bidehex-1.2.0.jar --verbose
    
    if command -v editbin 2>&1 >/dev/null
    then
        editbin /SUBSYSTEM:WINDOWS Bidehex-1.2.0.exe
    fi
    
    rm -rf META-INF/
elif command -v native-image 2>&1 >/dev/null
then
    if [ "$1" != "--skip-agent" ]; then
        mkdir -p META-INF/native-image
        echo "Close the app to continue..."
        java -agentlib:native-image-agent=config-output-dir=META-INF/native-image -jar ./Bidehex-1.2.0.jar
        sleep 1s
    fi

    native-image -jar ./Bidehex-1.2.0.jar --verbose

    rm -rf META-INF/
else
    echo "Native image not found! GraalVM was not installed!"
fi