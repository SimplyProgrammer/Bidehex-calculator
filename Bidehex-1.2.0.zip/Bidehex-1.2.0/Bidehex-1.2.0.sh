./.setup-env.sh

if [ "$1" == '--debug' ] ; then
	java -jar "./Bidehex-1.2.0.jar"
else
	java -jar "./Bidehex-1.2.0.jar" &
fi